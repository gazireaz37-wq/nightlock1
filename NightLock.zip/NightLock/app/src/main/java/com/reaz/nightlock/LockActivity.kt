package com.reaz.nightlock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LockActivity : Activity() {

    private var leaveOk = false

    private fun tv(t: String, size: Float, bottom: Int): TextView = TextView(this).apply {
        text = t
        textSize = size
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, bottom)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val msg = Prefs.msg(this)
        val endText = Prefs.fmt(Prefs.currentEnd(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(64, 160, 64, 64)
        }
        root.addView(tv("😴 $msg", 26f, 24))
        root.addView(tv("ফোন $endText পর্যন্ত লক থাকবে।", 18f, 48))

        // অনুমোদিত অ্যাপ
        val allowed = Prefs.allowed(this)
        if (allowed.isNotEmpty() && Perm.usageAccess(this)) {
            root.addView(tv("অনুমোদিত অ্যাপ", 16f, 8))
            for (pkg in allowed) {
                val launch = packageManager.getLaunchIntentForPackage(pkg) ?: continue
                val name = try {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) { pkg }
                val btn = Button(this)
                btn.text = name
                btn.setOnClickListener {
                    startService(Intent(this, LockService::class.java).putExtra("watch", pkg))
                    leaveOk = true
                    startActivity(launch)
                    finish()
                }
                root.addView(btn, LinearLayout.LayoutParams(-1, -2))
            }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        shown = true
    }

    // এই পর্দা ছেড়ে গেলেই আবার লক
    override fun onPause() {
        super.onPause()
        shown = false
        if (!leaveOk && Prefs.shouldLock(this)) LockService.lockNow(this)
    }

    companion object {
        @Volatile var shown = false
    }
}
