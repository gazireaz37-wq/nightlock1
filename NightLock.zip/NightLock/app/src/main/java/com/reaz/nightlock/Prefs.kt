package com.reaz.nightlock

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

object Perm {
    @Suppress("DEPRECATION")
    fun usageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }
}

data class Night(val key: String, var att: Int, var em: Int)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    // ---- ডিফল্ট সময় (মিনিট; রাত ১২:৩০ = 30, সকাল ৬:০০ = 360) ----
    fun start(c: Context) = sp(c).getInt("start", 30)
    fun end(c: Context) = sp(c).getInt("end", 360)
    fun setStart(c: Context, v: Int) = sp(c).edit().putInt("start", v).apply()
    fun setEnd(c: Context, v: Int) = sp(c).edit().putInt("end", v).apply()

    // ---- দিনভেদে আলাদা সময় (0 = রবি ... 6 = শনি) ----
    fun startFor(c: Context, dow: Int) = sp(c).getInt("s_$dow", start(c))
    fun endFor(c: Context, dow: Int) = sp(c).getInt("e_$dow", end(c))
    fun setDaySchedule(c: Context, dow: Int, s: Int, e: Int) =
        sp(c).edit().putInt("s_$dow", s).putInt("e_$dow", e).apply()
    fun clearDaySchedules(c: Context) {
        val ed = sp(c).edit()
        for (i in 0..6) { ed.remove("s_$i"); ed.remove("e_$i") }
        ed.apply()
    }

    // কোন কোন রাতে লক (বিট 0 = রবি ... বিট 6 = শনি)
    fun days(c: Context) = sp(c).getInt("days", 127)
    fun setDays(c: Context, v: Int) = sp(c).edit().putInt("days", v).apply()

    // ---- লক পর্দার বার্তা ----
    fun msg(c: Context) = sp(c).getString("msg", "এখন ঘুমের সময়") ?: "এখন ঘুমের সময়"
    fun setMsg(c: Context, v: String) = sp(c).edit().putString("msg", v).apply()

    // ---- গোপন মোড ও এলোমেলো দেরি ----
    fun stealth(c: Context) = sp(c).getBoolean("stealth", false)
    fun setStealth(c: Context, v: Boolean) = sp(c).edit().putBoolean("stealth", v).apply()

    fun jitterMax(c: Context) = sp(c).getInt("jitter", 0)
    fun setJitter(c: Context, v: Int) = sp(c).edit().putInt("jitter", v).apply()

    /** প্রতি রাতের জন্য গোপনে ঠিক করা এলোমেলো দেরি (মিনিট) */
    private fun jitterFor(c: Context): Int {
        val j = jitterMax(c)
        if (j <= 0) return 0
        var salt = sp(c).getString("jsalt", null)
        if (salt == null) {
            salt = UUID.randomUUID().toString()
            sp(c).edit().putString("jsalt", salt).apply()
        }
        return ((nightKey() + salt).hashCode() and 0x7fffffff) % (j + 1)
    }

    // ---- লক সময়ে অনুমোদিত অ্যাপ ----
    fun allowed(c: Context): Set<String> = HashSet(sp(c).getStringSet("allow", emptySet()) ?: emptySet())
    fun setAllowed(c: Context, s: Set<String>) = sp(c).edit().putStringSet("allow", HashSet(s)).apply()

    // ---- পাসওয়ার্ড ----
    private fun hash(s: String) =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPass(c: Context) = sp(c).contains("hash")
    fun setPass(c: Context, p: String) {
        val salt = UUID.randomUUID().toString()
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt + p)).apply()
    }
    fun checkPass(c: Context, p: String): Boolean {
        val salt = sp(c).getString("salt", "") ?: ""
        return hash(salt + p) == sp(c).getString("hash", "")
    }

    // ---- রাত কোন দিনের ----
    // দুপুরের আগের সময় আগের দিনের রাত হিসেবে ধরা হয়
    // (যেমন শুক্রবার = শুক্রবার সন্ধ্যা থেকে শনিবার ভোর)
    private fun nightCal(cal: Calendar): Calendar {
        val c = cal.clone() as Calendar
        if (c.get(Calendar.HOUR_OF_DAY) < 12) c.add(Calendar.DAY_OF_YEAR, -1)
        return c
    }

    private fun nightKey(): String {
        val n = nightCal(Calendar.getInstance())
        return "%04d-%02d-%02d".format(n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DAY_OF_MONTH))
    }

    /** এই রাতের লক শেষের সময় (মিনিট) */
    fun currentEnd(c: Context): Int =
        endFor(c, nightCal(Calendar.getInstance()).get(Calendar.DAY_OF_WEEK) - 1)

    // ---- লক সময় ----
    fun inLockWindow(c: Context): Boolean {
        if (!enabled(c)) return false
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val d = nightCal(now).get(Calendar.DAY_OF_WEEK) - 1
        val s0 = startFor(c, d)
        val e = endFor(c, d)
        val j = jitterFor(c)
        val s = if (s0 <= e) minOf(s0 + j, maxOf(s0, e - 1)) else (s0 + j) % 1440
        val inTime = if (s <= e) m in s until e else (m >= s || m < e)
        return inTime && (days(c) and (1 shl d)) != 0
    }

    fun shouldLock(c: Context) = inLockWindow(c)

    /** লক শুরুর আগের ১–১৫ মিনিটে বাকি মিনিট, নাহলে null */
    fun minutesToLock(c: Context): Int? {
        if (!enabled(c)) return null
        val now = Calendar.getInstance()
        now.set(Calendar.SECOND, 0)
        now.set(Calendar.MILLISECOND, 0)
        for (off in -1..1) {
            val d = now.clone() as Calendar
            d.add(Calendar.DAY_OF_YEAR, off)
            val dow = d.get(Calendar.DAY_OF_WEEK) - 1
            if ((days(c) and (1 shl dow)) == 0) continue
            val s = startFor(c, dow)
            val st = d.clone() as Calendar
            if (s < 720) st.add(Calendar.DAY_OF_YEAR, 1)
            st.set(Calendar.HOUR_OF_DAY, s / 60)
            st.set(Calendar.MINUTE, s % 60)
            val diff = ((st.timeInMillis - now.timeInMillis) / 60000).toInt()
            if (diff in 1..15) return diff
        }
        return null
    }

    // ---- রাতের রেকর্ড ----
    private fun loadNights(c: Context): MutableList<Night> {
        val raw = sp(c).getString("nights", "") ?: ""
        if (raw.isEmpty()) return mutableListOf()
        return raw.split(";").mapNotNull { p ->
            val f = p.split(":")
            if (f.size == 3) Night(f[0], f[1].toIntOrNull() ?: 0, f[2].toIntOrNull() ?: 0) else null
        }.toMutableList()
    }

    private fun saveNights(c: Context, l: List<Night>) {
        val t = if (l.size > 60) l.takeLast(60) else l
        sp(c).edit().putString("nights", t.joinToString(";") { "${it.key}:${it.att}:${it.em}" }).apply()
    }

    private fun night(l: MutableList<Night>): Night {
        val k = nightKey()
        val found = l.firstOrNull { it.key == k }
        if (found != null) return found
        val n = Night(k, 0, 0)
        l.add(n)
        return n
    }

    fun touchNight(c: Context) {
        val l = loadNights(c)
        val before = l.size
        night(l)
        if (l.size != before) saveNights(c, l)
    }

    fun addAttempt(c: Context) {
        val l = loadNights(c)
        night(l).att++
        saveNights(c, l)
    }

    private fun finishedNights(c: Context): List<Night> {
        val l = loadNights(c)
        val k = nightKey()
        return if (inLockWindow(c)) l.filter { it.key != k } else l
    }

    /** টানা কত রাত ফোন খোলার চেষ্টা ছাড়া কেটেছে */
    fun streak(c: Context): Int {
        var n = 0
        for (x in finishedNights(c).asReversed()) {
            if (x.att == 0) n++ else break
        }
        return n
    }

    fun recentNights(c: Context): List<Night> = loadNights(c).takeLast(7).reversed()

    // ---- স্ট্যাটাস (উইজেট ও টাইলের জন্য) ----
    /** পরের লক শুরুর আগে কত মিনিট বাকি (ডিফল্ট/দিনভেদে সময় অনুযায়ী) */
    fun minutesToNextLock(c: Context): Int? {
        val now = Calendar.getInstance()
        now.set(Calendar.SECOND, 0)
        now.set(Calendar.MILLISECOND, 0)
        var best: Int? = null
        for (off in -1..8) {
            val d = now.clone() as Calendar
            d.add(Calendar.DAY_OF_YEAR, off)
            val dow = d.get(Calendar.DAY_OF_WEEK) - 1
            if ((days(c) and (1 shl dow)) == 0) continue
            val s = startFor(c, dow)
            val st = d.clone() as Calendar
            if (s < 720) st.add(Calendar.DAY_OF_YEAR, 1)
            st.set(Calendar.HOUR_OF_DAY, s / 60)
            st.set(Calendar.MINUTE, s % 60)
            val diff = ((st.timeInMillis - now.timeInMillis) / 60000).toInt()
            val b = best
            if (diff > 0 && (b == null || diff < b)) best = diff
        }
        return best
    }

    fun humanDuration(min: Int): String {
        val d = min / 1440
        val h = (min % 1440) / 60
        val m = min % 60
        val sb = StringBuilder()
        if (d > 0) sb.append("$d দিন ")
        if (h > 0) sb.append("$h ঘণ্টা ")
        if (m > 0 || (d == 0 && h == 0)) sb.append("$m মিনিট")
        return sb.toString().trim()
    }

    fun shortStatus(c: Context): String {
        if (!enabled(c)) return "বন্ধ আছে"
        if (inLockWindow(c)) return "এখন লক চলছে"
        val m = minutesToNextLock(c) ?: return "কোনো রাত বাছা নেই"
        return "লক হতে ${humanDuration(m)}"
    }

    fun fmt(min: Int): String {
        val h24 = min / 60
        val m = min % 60
        val ampm = if (h24 < 12) "AM" else "PM"
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        return "%d:%02d %s".format(h, m, ampm)
    }
}

object Stealth {
    private const val ALIAS = "com.reaz.nightlock.LauncherAlias"

    fun setIconVisible(c: Context, visible: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            ComponentName(c.packageName, ALIAS),
            if (visible) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
