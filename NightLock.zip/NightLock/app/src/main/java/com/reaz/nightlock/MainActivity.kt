package com.reaz.nightlock

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val dayNames = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var btnAdmin: Button
    private lateinit var btnOverlay: Button
    private lateinit var btnUsage: Button
    private lateinit var btnPass: Button
    private lateinit var btnDays: Button
    private lateinit var btnStart: Button
    private lateinit var btnEnd: Button
    private lateinit var btnMsg: Button
    private lateinit var btnApps: Button
    private lateinit var btnStealth: Button
    private lateinit var btnJitter: Button
    private lateinit var btnToggle: Button

    private val admin by lazy { ComponentName(this, AdminReceiver::class.java) }
    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }

    private fun btn(onClick: () -> Unit): Button = Button(this).apply {
        textSize = 15f
        setOnClickListener { onClick() }
        root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
    }

    private fun heading(t: String) {
        root.addView(TextView(this).apply {
            text = t
            textSize = 14f
            setPadding(0, 40, 0, 0)
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 96)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "🔒 রাতের লক"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 32, 0, 8) }
        root.addView(status)

        btnToggle = btn { toggle() }
        btn { showStats() }.text = "📊 রাতের রেকর্ড"

        heading("অনুমতি")
        btnAdmin = btn { requestAdmin() }
        btnOverlay = btn { requestOverlay() }
        btnUsage = btn { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn { ignoreBattery() }.text = "ব্যাটারি অপটিমাইজেশন বন্ধ করুন (জরুরি)"

        heading("সেটিংস")
        btnPass = btn { guard { setPassword() } }
        btnDays = btn { pickDays() }
        btnStart = btn { pickTime(true) }
        btnEnd = btn { pickTime(false) }
        btn { pickDaySchedules() }.text = "দিনভেদে আলাদা সময়"
        btnMsg = btn { editMessage() }
        btnApps = btn { pickApps() }
        btnJitter = btn { jitterSettings() }
        btnStealth = btn { toggleStealth() }

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.enabled(this)) startForegroundService(Intent(this, LockService::class.java))
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun daysText(): String {
        val m = Prefs.days(this)
        if (m == 127) return "প্রতি রাত"
        if (m == 0) return "কোনো রাত নয়"
        return dayNames.indices.filter { (m and (1 shl it)) != 0 }
            .joinToString(", ") { dayNames[it].removeSuffix("বার") }
    }

    private fun refresh() {
        LockWidget.updateAll(this)
        val isAdmin = dpm.isAdminActive(admin)
        val overlay = Settings.canDrawOverlays(this)
        val usage = Perm.usageAccess(this)
        btnAdmin.text = if (isAdmin) "✅ অ্যাডমিন অনুমতি আছে" else "১) অ্যাডমিন অনুমতি দিন"
        btnAdmin.isEnabled = !isAdmin
        btnOverlay.text = if (overlay) "✅ লক পর্দার অনুমতি আছে" else "২) অন্য অ্যাপের উপরে দেখানোর অনুমতি দিন"
        btnOverlay.isEnabled = !overlay
        btnUsage.text = if (usage) "✅ ইউসেজ অ্যাক্সেস আছে" else "অনুমোদিত অ্যাপের জন্য ইউসেজ অ্যাক্সেস দিন"
        btnUsage.isEnabled = !usage
        btnPass.text = if (Prefs.hasPass(this)) "পাসওয়ার্ড বদলান" else "৩) পাসওয়ার্ড সেট করুন"
        btnDays.text = "যেসব রাতে লক: ${daysText()}"
        btnStart.text = "ডিফল্ট লক শুরু: ${Prefs.fmt(Prefs.start(this))}"
        btnEnd.text = "ডিফল্ট লক শেষ: ${Prefs.fmt(Prefs.end(this))}"
        btnMsg.text = "লক পর্দার বার্তা: ${Prefs.msg(this)}"
        btnApps.text = "লক সময়ে অনুমোদিত অ্যাপ (${Prefs.allowed(this).size}টি)"
        btnJitter.text = "লক শুরুর এলোমেলো দেরি: ${Prefs.jitterMax(this)} মিনিট"
        btnStealth.text = if (Prefs.stealth(this)) "🕶 গোপন মোড: চালু" else "🕶 গোপন মোড: বন্ধ"
        btnToggle.text = if (Prefs.enabled(this)) "লক বন্ধ করুন" else "৪) লক চালু করুন"
        status.text = when {
            !isAdmin -> "আগে অ্যাডমিন অনুমতি দিন।"
            Prefs.enabled(this) ->
                "চালু আছে — ${daysText()} লক।\nটানা পরিষ্কার রাত: ${Prefs.streak(this)}"
            else -> "বন্ধ আছে।"
        }
    }

    // ---- পাসওয়ার্ড ----
    // লক চালু থাকলে যেকোনো বদল করতে পাসওয়ার্ড লাগবে
    private fun guard(action: () -> Unit) {
        if (!Prefs.enabled(this) || !Prefs.hasPass(this)) { action(); return }
        val et = pwField("পাসওয়ার্ড")
        AlertDialog.Builder(this)
            .setTitle("পাসওয়ার্ড দিন")
            .setView(wrap(et))
            .setPositiveButton("ঠিক আছে") { _, _ ->
                if (Prefs.checkPass(this, et.text.toString())) action() else toast("ভুল পাসওয়ার্ড")
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun pwField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun numField(h: String, v: Int) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v.toString())
    }

    private fun wrap(vararg v: EditText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 16, 48, 0)
        v.forEach { addView(it) }
    }

    private fun setPassword() {
        val a = pwField("নতুন পাসওয়ার্ড (কমপক্ষে ৪ অক্ষর)")
        val b = pwField("আবার লিখুন")
        AlertDialog.Builder(this)
            .setTitle("পাসওয়ার্ড সেট করুন")
            .setView(wrap(a, b))
            .setPositiveButton("সেভ") { _, _ ->
                val p = a.text.toString()
                when {
                    p.length < 4 -> toast("কমপক্ষে ৪ অক্ষর দিন")
                    p != b.text.toString() -> toast("দুটো মিলছে না")
                    else -> { Prefs.setPass(this, p); refresh() }
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---- অনুমতি ----
    private fun requestAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "নির্ধারিত রাতের সময়ে ফোন লক করার জন্য এই অনুমতি দরকার।")
        })
    }

    private fun requestOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun ignoreBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("আগে থেকেই বন্ধ করা আছে ✅")
        } else {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }

    // ---- দিন ও সময় ----
    private fun pickDays() = guard {
        val m = Prefs.days(this)
        val checked = BooleanArray(7) { (m and (1 shl it)) != 0 }
        AlertDialog.Builder(this)
            .setTitle("যেসব রাতে লক (সন্ধ্যার দিন)")
            .setMultiChoiceItems(dayNames, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("সেভ") { _, _ ->
                var mask = 0
                checked.forEachIndexed { i, v -> if (v) mask = mask or (1 shl i) }
                Prefs.setDays(this, mask)
                refresh()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun pickTime(isStart: Boolean) = guard {
        val cur = if (isStart) Prefs.start(this) else Prefs.end(this)
        TimePickerDialog(this, { _, h, m ->
            if (isStart) Prefs.setStart(this, h * 60 + m) else Prefs.setEnd(this, h * 60 + m)
            refresh()
        }, cur / 60, cur % 60, false).show()
    }

    private fun pickDaySchedules() = guard { showDayList() }

    private fun showDayList() {
        val items = Array(7) { i ->
            "${dayNames[i]}: ${Prefs.fmt(Prefs.startFor(this, i))} – ${Prefs.fmt(Prefs.endFor(this, i))}"
        }
        AlertDialog.Builder(this)
            .setTitle("দিনভেদে সময় (দিন ট্যাপ করুন)")
            .setItems(items) { _, i -> editDay(i) }
            .setNeutralButton("সব রিসেট") { _, _ -> Prefs.clearDaySchedules(this); refresh() }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun editDay(i: Int) {
        val s0 = Prefs.startFor(this, i)
        val e0 = Prefs.endFor(this, i)
        val first = TimePickerDialog(this, { _, h, m ->
            val s = h * 60 + m
            val second = TimePickerDialog(this, { _, h2, m2 ->
                Prefs.setDaySchedule(this, i, s, h2 * 60 + m2)
                refresh()
                showDayList()
            }, e0 / 60, e0 % 60, false)
            second.setTitle("${dayNames[i]} — লক শেষ")
            second.show()
        }, s0 / 60, s0 % 60, false)
        first.setTitle("${dayNames[i]} — লক শুরু")
        first.show()
    }

    // ---- বার্তা ----
    private fun editMessage() = guard {
        val et = EditText(this)
        et.setText(Prefs.msg(this))
        et.hint = "লক পর্দার বার্তা"
        AlertDialog.Builder(this)
            .setTitle("লক পর্দার বার্তা")
            .setView(wrap(et))
            .setPositiveButton("সেভ") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) { Prefs.setMsg(this, t); refresh() }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---- অনুমোদিত অ্যাপ ----
    @Suppress("DEPRECATION")
    private fun pickApps() = guard {
        if (!Perm.usageAccess(this)) {
            toast("আগে ইউসেজ অ্যাক্সেস অনুমতি দিন")
            return@guard
        }
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val cur = Prefs.allowed(this)
        val checked = BooleanArray(apps.size) { apps[it].first in cur }
        AlertDialog.Builder(this)
            .setTitle("লক সময়ে যেসব অ্যাপ চলবে")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("সেভ") { _, _ ->
                val set = HashSet<String>()
                checked.forEachIndexed { i, v -> if (v) set.add(apps[i].first) }
                Prefs.setAllowed(this, set)
                refresh()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---- গোপন মোড ----
    private fun jitterSettings() = guard {
        val a = numField("সর্বোচ্চ কত মিনিট দেরি (০ = ঠিক সময়ে, সর্বোচ্চ ৬০)", Prefs.jitterMax(this))
        AlertDialog.Builder(this)
            .setTitle("এলোমেলো দেরি")
            .setMessage("প্রতি রাতে লক শুরুর সময়ের পরে এই সীমার মধ্যে যেকোনো মিনিটে হঠাৎ লক হবে, কখন হবে আপনি আগে জানবেন না।")
            .setView(wrap(a))
            .setPositiveButton("সেভ") { _, _ ->
                val x = a.text.toString().toIntOrNull()
                if (x == null || x !in 0..60) toast("০ থেকে ৬০ এর মধ্যে দিন")
                else { Prefs.setJitter(this, x); refresh() }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun toggleStealth() = guard {
        if (Prefs.stealth(this)) {
            Prefs.setStealth(this, false)
            Stealth.setIconVisible(this, true)
            toast("গোপন মোড বন্ধ, আইকন ফিরে এসেছে")
            refresh()
        } else {
            AlertDialog.Builder(this)
                .setTitle("গোপন মোড চালু করবেন?")
                .setMessage(
                    "• অ্যাপের আইকন লুকিয়ে যাবে\n" +
                    "• লকের আগে কোনো সতর্কবার্তা আসবে না\n" +
                    "• নোটিফিকেশন সাধারণ নামে ও লক পর্দায় লুকানো থাকবে\n\n" +
                    "অ্যাপ খুলতে নোটিফিকেশন প্যানেলের \"ব্যাকগ্রাউন্ড সার্ভিস\" লেখায় ট্যাপ করুন। " +
                    "আইকন ফিরিয়ে আনার আরেক উপায়: APK আবার ইনস্টল করা।"
                )
                .setPositiveButton("চালু করুন") { _, _ ->
                    Prefs.setStealth(this, true)
                    Stealth.setIconVisible(this, false)
                    refresh()
                }
                .setNegativeButton("বাতিল", null)
                .show()
        }
    }

    // ---- রেকর্ড ----
    private fun showStats() {
        val sb = StringBuilder()
        sb.append("টানা পরিষ্কার রাত (ফোন খোলার চেষ্টা ছাড়া): ${Prefs.streak(this)}\n\nশেষ ৭ রাত:\n")
        val l = Prefs.recentNights(this)
        if (l.isEmpty()) sb.append("এখনো কোনো রেকর্ড নেই\n")
        else l.forEach { sb.append("${it.key}: আনলকের চেষ্টা ${it.att}\n") }
        AlertDialog.Builder(this)
            .setTitle("রেকর্ড")
            .setMessage(sb.toString())
            .setPositiveButton("ঠিক আছে", null)
            .show()
    }

    // ---- চালু/বন্ধ ----
    private fun toggle() {
        if (!dpm.isAdminActive(admin)) { toast("আগে অ্যাডমিন অনুমতি দিন"); return }
        if (!Prefs.enabled(this)) {
            if (!Prefs.hasPass(this)) { toast("আগে পাসওয়ার্ড সেট করুন"); return }
            Prefs.setEnabled(this, true)
            startForegroundService(Intent(this, LockService::class.java))
            refresh()
        } else {
            guard {
                Prefs.setEnabled(this, false)
                stopService(Intent(this, LockService::class.java))
                refresh()
            }
        }
    }
}
