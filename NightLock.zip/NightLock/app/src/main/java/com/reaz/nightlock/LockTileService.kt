package com.reaz.nightlock

import android.app.PendingIntent
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class LockTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminOk = dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
        if (!Prefs.enabled(this) && adminOk && Prefs.hasPass(this)) {
            // চালু করা নিরাপদ, তাই সরাসরি চালু হবে। বন্ধ করতে অ্যাপে পাসওয়ার্ড লাগবে।
            Prefs.setEnabled(this, true)
            startForegroundService(Intent(this, LockService::class.java))
            LockWidget.updateAll(this)
            refreshTile()
        } else {
            openApp()
        }
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            startActivityAndCollapse(i)
        }
    }

    private fun refreshTile() {
        val t = qsTile ?: return
        t.label = if (Prefs.stealth(this)) "ব্যাকগ্রাউন্ড" else "রাতের লক"
        t.icon = Icon.createWithResource(this, android.R.drawable.ic_lock_idle_lock)
        t.state = if (Prefs.enabled(this)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = Prefs.shortStatus(this)
        t.updateTile()
    }
}
